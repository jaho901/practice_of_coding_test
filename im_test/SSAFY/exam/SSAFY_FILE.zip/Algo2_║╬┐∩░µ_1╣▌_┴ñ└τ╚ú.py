
T = int(input())
for tc in range(1, T+1):
    N = int(input())
    # 좌상_x, 좌상_y, 우하_x, 우하_y값을 순서대로 받아온다.
    lt_x, lt_y, rb_x, rb_y = map(int, input().split())
    # 전체 데이터를 받아온다.
    data = [list(map(int, input().split())) for _ in range(N)]

    # 내가 평탄화 작업을 실시할 범위는 (rb_x - lt_x + 1) X (rb_y - lt_y + 1)이 된다.
    # 평탄화 작업을 실시할 배열을 새로 생성해준다.
    arr = [[0]*(rb_y - lt_y + 1) for _ in range(rb_x - lt_x + 1)]

    # 새로 만든 배열에 데이터에서 받은 값을 넣어준다.
    for i in range(len(arr)):
        for j in range(len(arr[0])):
            arr[i][j] = data[i+lt_x][j+lt_y]
    # 총합
    total = 0
    for k in range(len(arr)):
        for l in range(len(arr[0])):
            total += arr[k][l]
    length = len(arr) * (len(arr[0]))
    # 나누기 결과 소수점 이하는 무시한 정수가 되기 때문에 int를 통해 정수로 만들어준다.
    avg = int(total/length)

    # 평탄화 작업 시작!!
    # 모든 arr를 돌면서 차이값들을 구하자.
    # arr에 존재하는 값이 평균보다 클수도 있고, 작을수도 있기 때문에 절댓값으로 추가해주자.
    # 그 결과값을 넣을 result 생성
    result = 0
    for x in range(len(arr)):
        for y in range(len(arr[0])):
            result += abs(arr[x][y] - avg)

    print('#{} {} {}'.format(tc, avg, result))


