
T = int(input())
for tc in range(1, T + 1):
    # 정수 N과 M을 받아왔습니다.
    N, M = map(int, input().split())
    # 정수 N개의 데이터를 number라는 list로 받아왔습니다.
    number = list(map(int, input().split()))

    # 총 돌아가는 개수는 N - M + 1번 돌아가게 되어있다. 즉, 반복문의 범위 지정
    # for example, [1,2,3], [2,3,4], [3,4,6] 3번
    # 6개에서는 [603, 5178, 8071], [5178, 8071, 7796], [8071, 7796, 5917], [7796, 5917, 1282]
    # 위와 같이 4번이므로 6-3+1이 된다.

    # 모든 결과값을 저장할 리스트
    result = []
    # 위에서 정한 범위로 반복문 수행
    for i in range(N - M + 1):
        # i가 변경될때마다 최댓값, 최소값 초기화
        maximum = number[i]
        minimum = number[i]
        # 하나의 그룹의 시작인 i부터 i+1, ..., i+M-1까지 돌려야하기때문에
        # 아래와 같은 범위로 지정
        for j in range(i+1, i+M):
            # 각각의 그룹에서 계속해서 최대, 최소 비교하며 갱신
            if maximum < number[j]:
                maximum = number[j]
            if minimum > number[j]:
                minimum = number[j]
        # i가 변경되기 직전 최댓값과 최솟값의 차이를 result에 추가
        result.append(maximum - minimum)
    # 리스트 안에 들어있는 값들을 띄어쓰기를 하며 나오게 설정
    result = ' '.join(map(str, result))

    print('#{} {}'.format(tc, result))

