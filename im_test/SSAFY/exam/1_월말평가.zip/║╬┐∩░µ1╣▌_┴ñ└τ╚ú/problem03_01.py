import json

# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def is_password_verified(data):
    # 비밀번호를 pass_first 변수에, 비밀번화 확인값을 pass_again 변수에 할당
    pass_first = data['password']
    pass_again = data['password_confirm']
    
    # 조건문을 통해 두 변수가 동일한지 확인
    if pass_first == pass_again:
        return True
    return False

    # True를 반환해 비밀번호와 비밀번호 확인값이 동일함을 알 수 있다.

    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    user_data = open('problem03_data.json', encoding='UTF8')
    user_data = json.load(user_data)
    print(is_password_verified(user_data))
    # True
    