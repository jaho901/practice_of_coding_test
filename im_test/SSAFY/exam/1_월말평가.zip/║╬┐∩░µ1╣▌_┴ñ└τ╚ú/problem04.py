# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def caesar(word, n):
    word_list = list(word)
    result_list = []
    for i in word_list:
        word_num1 = ord(i)
        # 대문자인 경우 대문자에서만
        if word_num1 <= 90:
            word_num = word_num1 + n
            if word_num > 90:
                word_num2 = word_num - 26   # 만약 65~90 범주를 넘어가면 다시 65부터 돌아가기
                result_list.append(chr(word_num2))
            else:
                result_list.append(chr(word_num))
        # 소문자인 경우 소문자에서만
        elif word_num1 <= 122:
            word_num = word_num1 + n
            if word_num > 122:
                word_num2 = word_num - 26   # 만약 97 ~ 122 범주를 넘어가면 다시 97부터 돌아가기
                result_list.append(chr(word_num2))
            else:
                result_list.append(chr(word_num))    

    return ''.join(result_list)

    # 결과 동일함을 알 수 있다.

    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    print(caesar('apple', 5))
    # fuuqj
    print(caesar('ssafy', 1))
    # ttbgz
    print(caesar('Python', 10))
    # Zidryx