import json

# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def title_length(movie):
    # moive데이터에서 'title'을 들고온다.
    title = movie['title']
    # 그 이후 'title'의 글자 수를 len으로 반환해 return해준다.
    return len(title)

    # 제목이 총 4글자임을 알 수 있다.

    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    movie_json = open('problem02_data.json', encoding='UTF8')
    movie = json.load(movie_json)
    print(title_length(movie)) 
    # 4