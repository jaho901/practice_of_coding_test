import json

# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def over(movie):
    # 유저 평점을 확인하기 위해 변수 user_rating 확인
    rating = movie['user_rating']

    # rating값의 조건을 주어주고 return 하기
    if rating >= 8:
        return True
    else:
        return False

    # 평점이 9.5 즉, 8 이상이라서 True값을 반환한다.

    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    movie_json = open('problem02_data.json', encoding='UTF8')
    movie = json.load(movie_json)
    print(over(movie)) 
    # True