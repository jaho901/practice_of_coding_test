# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def get_final_position(N, mat, moves):

    pos = (0, 0)
    for i in moves:
        if i == 0:
            pos = (pos[0], pos[1] - 1)
        elif i == 1:
            pos = (pos[0], pos[1] + 1)
        elif i == 2:
            pos = (pos[0] - 1, pos[1])
        elif i == 3:
            pos = (pos[0] + 1, pos[1])

    if not 1 <= pos[0] <= N:
        return None
    elif not 1 <= pos[1] <= N:
        return None
    return list(pos)


    # 여기에 코드를 작성하여 함수를 완성합니다.
    # 3 * 3 평면
    #         -------------------------
    #         | (0,0) | (1,0) | (2,0) |
    #         -------------------------
    #         | (0,1) | (1,1) | (2,1) |
    #         -------------------------
    #         | (0,2) | (1,2) | (2,2) |
    #         -------------------------

# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    N = 3
    mat = [
        [1, 0, 0],
        [0, 0, 0],
        [0, 0, 0],
    ] 
    moves1 = [1, 1, 3]
    print(get_final_position(N, mat, moves1))
    # [1, 2]
    
    moves2 = [1, 3, 3]
    print(get_final_position(N, mat, moves2))
    # [2, 1]