# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def is_position_safe(N, M, position):
    # 3*3 범위에서
    # 키입력 = 0 위, 1 아래, 2 왼쪽, 3 오른쪽
    # 현재 위치 = (0,0) = position = (x, y)
    
    # 3 * 3 평면
    # (0,0)
    #         -------------------------
    #         | (1,1) | (2,1) | (3,1) |
    #         -------------------------
    #         | (1,2) | (2,2) | (3,2) |
    #         -------------------------
    #         | (1,3) | (2,3) | (3,3) |
    #         -------------------------

    # M의 값 만큼 현재 위치에서 이동? 문제 이해를 못하겠다...
    if M == 0:
        pos = (position[0], position[1] - 1)
    elif M == 1:
        pos = (position[0], position[1] + 1)
    elif M == 2:
        pos = (position[0] - 1, position[1])
    elif M == 3:
        pos = (position[0] + 1, position[1])

    # position이 N*N안에 속해있으면 True 아니면 False 반환
    if not 1 <= pos[0] <= N:
        return False
    elif not 1 <= pos[1] <= N:
        return False
    return True




    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    print(is_position_safe(3, 0, (0, 0)))
    # False