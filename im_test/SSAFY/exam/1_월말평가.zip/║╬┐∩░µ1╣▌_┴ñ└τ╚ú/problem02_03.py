import json

# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def history(movie):
    # 줄거리 overview를 over라는 변수에 저장하고 
    # 그 이후 find함수를 통해 '과거'라는 단어가 존재하는지를 찾는다.
    over = movie['overview']
    exist = over.find('과거')

    # 조건문을 사용해서 결과 exist가 1이면 과거를 포함해 True, 
    # 아니면(-1을 포함해서) 포함하지 않아서 False를 반환하게 한다.
    if exist == 1:
        return True
    else:
        return False
    
    # 결과, 포함하지 않기 때문에 False를 반환한다.

    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    movie_json = open('problem02_data.json', encoding='UTF8')
    movie = json.load(movie_json)
    print(history(movie)) 
    # False