import json

# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def check_password_number_case(data):
    # 반복문을 통해 key가 password일 때의 값을 password변수에 저장
    for i in data.keys():
        if i == 'password':
            password = data[i]
    
    # password 변수를 list로 변환 이후 반복문을 통해 숫자가 존재하는지의 여부 저장
    pass_list = list(password)
    result = []
    for i in pass_list:
        if i.isdigit() == True:
            result.append('True')
        else:
            result.append('False')

    # 조건문을 통해 result에 'True'가 하나라도 있으면 True반환하기
    if 'True' in result:
        return True
    else:
        return False

    # 비밀번호에 숫자가 존재함으로 True 반환


    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    user_data = open('problem03_data.json', encoding='UTF8')
    user_data = json.load(user_data)
    print(check_password_number_case(user_data))
    # True