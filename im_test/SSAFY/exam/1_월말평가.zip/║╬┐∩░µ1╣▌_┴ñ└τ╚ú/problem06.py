# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def rock_paper_scissors(data):
    # 0 = 가위, 1 = 바위, 2 = 보
    # 0 > 2, 1 > 0, 2 > 1
    # 각각의 결과를 result에 저장
    result = []
    for game in data:
        if game[0] == 0:
            if game[1] == 0:
                result.append('draw')
            elif game[1] == 1:
                result.append('B')
            elif game[1] == 2:
                result.append('A')
        elif game[0] == 1:
            if game[1] == 0:
                result.append('A')
            elif game[1] == 1:
                result.append('draw')
            elif game[1] == 2:
                result.append('B')
        elif game[0] == 2:
            if game[1] == 0:
                result.append('B')
            elif game[1] == 1:
                result.append('A')
            elif game[1] == 2:
                result.append('draw')

    # 결과의 개수에 따른 승자 여부 return
    if result.count('A') == result.count('B'):
        return 'draw'
    elif result.count('A') > result.count('B'):
        return 'A'
    elif result.count('B') > result.count('A'):
        return 'B'


    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    print(rock_paper_scissors([[0, 1], [1, 2], [2, 2]]))
    # B
    print(rock_paper_scissors([[0, 1], [1, 0]]))
    # draw