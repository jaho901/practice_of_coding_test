# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def dec_to_bin(n):
    # n == 1일때 멈추면서 '1'추가
    if n == 1:
        return '1'

    # n > 1일때 재귀 반복
    elif n > 1:
        if n % 2 == 0:
            result = dec_to_bin(n//2) + '0'
            return result
        elif n % 2 == 1:
            result = dec_to_bin(n//2) + '1'
            return result
    
    # 여기에 코드를 작성하여 함수를 완성합니다.


# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    print(dec_to_bin(10))
    # 1010
    print(dec_to_bin(5))
    # 101
    print(dec_to_bin(50))
    # 110010