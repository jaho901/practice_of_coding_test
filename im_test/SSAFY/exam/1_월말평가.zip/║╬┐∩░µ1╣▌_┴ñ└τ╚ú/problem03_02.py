import json

# 함수 내부에 불필요한 print문이 있는 경우 오답으로 처리가 됩니다.
def check_id_length(data):
    # id 변수를 들고오자
    id = data['id']
    # id의 길이를 length변수에 저장
    length = len(id)
    
    # 조건문을 통해 이 아이디의 길이가 4이상 16이하인지 확인후 return
    if 4 <= length <= 16:
        return True
    return False

    # id의 길이가 9자이므로 (jungssafy) 조건만족 => True 반환 확인

    # 여기에 코드를 작성하여 함수를 완성합니다.
    

# 아래의 코드를 수정하거나 새롭게 추가하지 않습니다.
if __name__ == '__main__':
    user_data = open('problem03_data.json', encoding='UTF8')
    user_data = json.load(user_data)
    print(check_id_length(user_data))
    # True